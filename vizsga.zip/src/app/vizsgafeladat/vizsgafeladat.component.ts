import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrl: './vizsgafeladat.component.css'
})
export class VizsgafeladatComponent {
  szoveg!:string;
  suly!:number;
  magassag!:number;
  TTI!:number;
  lista:string[]=[];
  kiiratas!:any;
  
  
 
testtomeg():void{
  let magassag:number=this.magassag*this.magassag;
  this.TTI=this.suly/magassag;
  this.szoveg="A megadott értékek alapján a testtömeg index:"
}

EredmenyMentes():void{
  let Suly:string = this.suly.toString();
  let Magassag:string = this.magassag.toString();
  let tti:string = this.TTI.toString();
 
  this.lista.push("A(z) ",Suly,"kg testsúlyú és",Magassag,"m magasságú ember testtömeg indexe:",tti);

}

}


